const array = [
  {
    status: 0,

    at: "1681981164894",
  },
  {
    status: 1,
    at: "1681982082010",
  },
  {
    status: 4,
    at: "1681982819607",
  },
  
];

console.log(array[array.length - 1]);


